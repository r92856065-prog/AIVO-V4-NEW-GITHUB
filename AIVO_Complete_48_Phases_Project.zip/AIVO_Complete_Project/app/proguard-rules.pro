-keepattributes *Annotation*
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
}
-keep class com.aivo.assistant.model.** { *; }
-dontwarn com.google.android.play.core.**
