package com.aivo.assistant

import com.aivo.assistant.core.ai.AivoTaskAgentEngine
import com.aivo.assistant.core.plugins.AivoPluginRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AivoCoreVerificationTest {
    @Test
    fun verifyAgentRequiresApprovalForSensitiveOperations() {
        val agent = AivoTaskAgentEngine()
        val steps = agent.planGoal("Send WhatsApp update to team")
        assertEquals(3, steps.size)
        val execStep = steps.last()
        assertTrue(execStep.requiresApproval)
        assertEquals("AWAITING_APPROVAL", execStep.status)

        agent.approveStep(execStep.stepNumber)
        assertEquals("COMPLETED", agent.steps.value.last().status)
    }

    @Test
    fun verifyPluginRegistryControls() {
        val registry = AivoPluginRegistry()
        val initial = registry.listPlugins()
        assertTrue(initial.isNotEmpty())
        registry.setPluginEnabled("health_connect", true)
        assertTrue(registry.listPlugins().first { it.id == "health_connect" }.enabled)
    }
}
