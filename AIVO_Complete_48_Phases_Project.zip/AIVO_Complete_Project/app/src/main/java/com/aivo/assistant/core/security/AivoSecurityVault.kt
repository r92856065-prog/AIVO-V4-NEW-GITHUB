package com.aivo.assistant.core.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class AivoSecurityVault(context: Context) {
    private val prefs: SharedPreferences = runCatching {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "aivo_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrElse {
        context.getSharedPreferences("aivo_fallback_prefs", Context.MODE_PRIVATE)
    }

    fun storeSecret(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun readSecret(key: String): String? = prefs.getString(key, null)

    fun removeSecret(key: String) {
        prefs.edit().remove(key).apply()
    }

    fun clearAllSecrets() {
        prefs.edit().clear().apply()
    }

    fun hashPassword(password: String, salt: ByteArray = generateSalt()): Pair<String, String> {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        val hashed = digest.digest(password.toByteArray(Charsets.UTF_8))
        return Base64.getEncoder().encodeToString(hashed) to Base64.getEncoder().encodeToString(salt)
    }

    fun verifyPassword(password: String, expectedHashBase64: String, saltBase64: String): Boolean {
        val salt = Base64.getDecoder().decode(saltBase64)
        val (computed, _) = hashPassword(password, salt)
        return MessageDigest.isEqual(computed.toByteArray(), expectedHashBase64.toByteArray())
    }

    fun encryptPayload(plainText: String, rawKey32Bytes: ByteArray): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(rawKey32Bytes.copyOf(32), "AES"), GCMParameterSpec(128, iv))
        val cipherBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return Base64.getEncoder().encodeToString(iv + cipherBytes)
    }

    fun decryptPayload(encoded: String, rawKey32Bytes: ByteArray): String {
        val all = Base64.getDecoder().decode(encoded)
        val iv = all.copyOfRange(0, 12)
        val cipherBytes = all.copyOfRange(12, all.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(rawKey32Bytes.copyOf(32), "AES"), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
    }

    private fun generateSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }
}
