package com.aivo.assistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val AivoAbyss = Color(0xFF050A14)
val AivoDeepNavy = Color(0xFF0B162C)
val AivoPanelBlue = Color(0xFF112240)
val AivoCyan = Color(0xFF00E5FF)
val AivoElectricBlue = Color(0xFF2979FF)
val AivoIceText = Color(0xFFE6F4FF)
val AivoMutedSlate = Color(0xFF8CA4C4)

private val DarkAivoColors = darkColorScheme(
    primary = AivoCyan,
    onPrimary = AivoAbyss,
    secondary = AivoElectricBlue,
    onSecondary = Color.White,
    background = AivoAbyss,
    onBackground = AivoIceText,
    surface = AivoDeepNavy,
    onSurface = AivoIceText,
    surfaceVariant = AivoPanelBlue,
    onSurfaceVariant = AivoMutedSlate
)

private val LightAivoColors = lightColorScheme(
    primary = Color(0xFF0066CC),
    onPrimary = Color.White,
    secondary = Color(0xFF0097A7),
    onSecondary = Color.White,
    background = Color(0xFFF3F8FF),
    onBackground = Color(0xFF0A192F),
    surface = Color.White,
    onSurface = Color(0xFF0A192F),
    surfaceVariant = Color(0xFFE1EEFF),
    onSurfaceVariant = Color(0xFF334E68)
)

@Composable
fun AivoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    fontScaleMultiplier: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkAivoColors else LightAivoColors
    val scaledTypography = Typography(
        headlineMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold,
            fontSize = (24 * fontScaleMultiplier).sp
        ),
        titleMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold,
            fontSize = (17 * fontScaleMultiplier).sp
        ),
        bodyLarge = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Normal,
            fontSize = (15 * fontScaleMultiplier).sp
        ),
        bodyMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Normal,
            fontSize = (13 * fontScaleMultiplier).sp
        )
    )
    MaterialTheme(
        colorScheme = colors,
        typography = scaledTypography,
        content = content
    )
}
