package com.aivo.assistant.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.aivo.assistant.core.voice.AvatarState

@Composable
fun AivoRobotAvatar(
    state: AvatarState,
    lightweightMode: Boolean = false,
    modifier: Modifier = Modifier.size(160.dp)
) {
    val transition = rememberInfiniteTransition(label = "aivo_avatar")
    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (state == AvatarState.SPEAKING) 280 else 1400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val lipScale by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = if (state == AvatarState.SPEAKING) 1.0f else 0.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(180),
            repeatMode = RepeatMode.Reverse
        ),
        label = "lip"
    )

    val coreCyan = when (state) {
        AvatarState.IDLE -> Color(0xFF00E5FF)
        AvatarState.LISTENING -> Color(0xFF00FFC8)
        AvatarState.THINKING -> Color(0xFF448AFF)
        AvatarState.SPEAKING -> Color(0xFF18FFFF)
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        if (!lightweightMode) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(coreCyan.copy(alpha = 0.32f), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = (w * 0.48f) * pulse
                ),
                radius = (w * 0.48f) * pulse,
                center = Offset(cx, cy)
            )
        }

        // Hexagonal Futuristic Robotic AI Head
        val headPath = Path().apply {
            moveTo(cx, h * 0.10f)
            lineTo(w * 0.78f, h * 0.24f)
            lineTo(w * 0.84f, h * 0.56f)
            lineTo(w * 0.70f, h * 0.84f)
            lineTo(cx, h * 0.92f)
            lineTo(w * 0.30f, h * 0.84f)
            lineTo(w * 0.16f, h * 0.56f)
            lineTo(w * 0.22f, h * 0.24f)
            close()
        }
        drawPath(headPath, color = Color(0xFF0D1F3C))
        drawPath(headPath, color = coreCyan, style = Stroke(width = 4f))

        // Optical Visor & Eyes
        drawRect(
            color = Color(0xFF031226),
            topLeft = Offset(w * 0.26f, h * 0.38f),
            size = Size(w * 0.48f, h * 0.18f)
        )
        drawCircle(color = coreCyan, radius = w * 0.055f, center = Offset(w * 0.38f, h * 0.47f))
        drawCircle(color = coreCyan, radius = w * 0.055f, center = Offset(w * 0.62f, h * 0.47f))

        // Synchronized Lip / Voice Equalizer Bars
        val barHeights = listOf(0.5f, 1.0f, 0.75f, 1.0f, 0.5f)
        barHeights.forEachIndexed { idx, factor ->
            val bx = w * (0.36f + idx * 0.07f)
            val bh = (h * 0.11f) * factor * lipScale
            drawRect(
                color = coreCyan,
                topLeft = Offset(bx, h * 0.70f - bh / 2f),
                size = Size(w * 0.04f, bh.coerceAtLeast(4f))
            )
        }
    }
}
