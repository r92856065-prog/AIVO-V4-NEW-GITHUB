package com.aivo.assistant.core.ai

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AgentStep(
    val stepNumber: Int,
    val description: String,
    val requiresApproval: Boolean,
    val status: String // PENDING, AWAITING_APPROVAL, COMPLETED, BLOCKED
)

class AivoTaskAgentEngine {
    private val _steps = MutableStateFlow<List<AgentStep>>(emptyList())
    val steps: StateFlow<List<AgentStep>> = _steps.asStateFlow()

    fun planGoal(goal: String): List<AgentStep> {
        val lower = goal.lowercase()
        val sensitive = listOf("send", "delete", "email", "whatsapp", "pc", "shutdown", "install").any { lower.contains(it) }
        val plan = listOf(
            AgentStep(1, "Analyze intent & check permissions for: $goal", false, "COMPLETED"),
            AgentStep(2, "Gather local memory, schedule, and context parameters", false, "COMPLETED"),
            AgentStep(
                3,
                "Execute target operation: $goal",
                requiresApproval = sensitive,
                status = if (sensitive) "AWAITING_APPROVAL" else "PENDING"
            )
        )
        _steps.value = plan
        return plan
    }

    fun approveStep(stepNumber: Int) {
        _steps.value = _steps.value.map {
            if (it.stepNumber == stepNumber) it.copy(status = "COMPLETED") else it
        }
    }
}
