package com.aivo.assistant.core.plugins

data class AivoPluginDescriptor(
    val id: String,
    val name: String,
    val requiredPermission: String,
    val enabled: Boolean,
    val description: String
)

class AivoPluginRegistry {
    private val plugins = linkedMapOf(
        "weather_open_meteo" to AivoPluginDescriptor("weather_open_meteo", "Open-Meteo Weather", "LOCATION_OPTIONAL", true, "Real-time meteorological forecast"),
        "health_connect" to AivoPluginDescriptor("health_connect", "Android Health Connect", "HEALTH_READ", false, "Steps, heart rate & sleep wellness metrics"),
        "pc_bridge" to AivoPluginDescriptor("pc_bridge", "Windows Remote Bridge", "PAIRED_DEVICE_AUTH", true, "Encrypted Phone-to-PC command bridge"),
        "web_research" to AivoPluginDescriptor("web_research", "Citation Web Search", "INTERNET", true, "Source-backed web verification")
    )

    fun listPlugins(): List<AivoPluginDescriptor> = plugins.values.toList()

    fun setPluginEnabled(id: String, enabled: Boolean) {
        plugins[id]?.let { plugins[id] = it.copy(enabled = enabled) }
    }
}
