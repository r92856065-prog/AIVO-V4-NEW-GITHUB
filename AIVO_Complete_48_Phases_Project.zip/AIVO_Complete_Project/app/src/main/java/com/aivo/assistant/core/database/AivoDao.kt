package com.aivo.assistant.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AivoDao {
    // Chat (Phase 3)
    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun observeMessages(sessionId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    suspend fun getAllMessages(): List<ChatMessageEntity>

    @Insert
    suspend fun insertMessage(msg: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages WHERE sessionId = :sessionId")
    suspend fun clearSession(sessionId: String)

    // Reminders (Phase 8)
    @Query("SELECT * FROM reminders ORDER BY dueAtMillis ASC")
    fun observeReminders(): Flow<List<ReminderEntity>>

    @Insert
    suspend fun insertReminder(reminder: ReminderEntity): Long

    @Update
    suspend fun updateReminder(reminder: ReminderEntity)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteReminder(id: Long)

    // Notification Center (Phase 7)
    @Query("SELECT * FROM notifications_log ORDER BY timestamp DESC")
    fun observeNotifications(): Flow<List<NotificationLogEntity>>

    @Insert
    suspend fun insertNotification(item: NotificationLogEntity): Long

    @Query("UPDATE notifications_log SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationRead(id: Long)

    @Query("DELETE FROM notifications_log")
    suspend fun clearNotifications()

    // Long-Term AI Memory (Phase 43)
    @Query("SELECT * FROM ai_memories ORDER BY updatedAt DESC")
    fun observeMemories(): Flow<List<AiMemoryEntity>>

    @Query("SELECT * FROM ai_memories WHERE userApproved = 1 ORDER BY updatedAt DESC")
    suspend fun getApprovedMemories(): List<AiMemoryEntity>

    @Insert
    suspend fun insertMemory(memory: AiMemoryEntity): Long

    @Update
    suspend fun updateMemory(memory: AiMemoryEntity)

    @Query("DELETE FROM ai_memories WHERE id = :id")
    suspend fun deleteMemory(id: Long)

    // Knowledge Base (Phase 34)
    @Query("SELECT * FROM knowledge_notes WHERE title LIKE '%' || :query || '%' OR body LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' ORDER BY updatedAt DESC")
    fun searchNotes(query: String): Flow<List<KnowledgeNoteEntity>>

    @Insert
    suspend fun insertNote(note: KnowledgeNoteEntity): Long

    @Update
    suspend fun updateNote(note: KnowledgeNoteEntity)

    @Query("DELETE FROM knowledge_notes WHERE id = :id")
    suspend fun deleteNote(id: Long)

    // Automation Workflows (Phase 31)
    @Query("SELECT * FROM automation_workflows ORDER BY id ASC")
    fun observeWorkflows(): Flow<List<WorkflowEntity>>

    @Insert
    suspend fun insertWorkflow(wf: WorkflowEntity): Long

    @Update
    suspend fun updateWorkflow(wf: WorkflowEntity)

    // Paired Devices (Phase 45)
    @Query("SELECT * FROM paired_devices ORDER BY pairedAt DESC")
    fun observePairedDevices(): Flow<List<PairedDeviceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPairedDevice(device: PairedDeviceEntity)

    @Query("DELETE FROM paired_devices WHERE deviceId = :deviceId")
    suspend fun revokePairedDevice(deviceId: String)
}
