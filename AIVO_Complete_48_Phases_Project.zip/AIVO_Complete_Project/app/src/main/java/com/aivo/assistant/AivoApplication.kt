package com.aivo.assistant

import android.app.Application
import com.aivo.assistant.core.di.AivoServiceLocator
import com.aivo.assistant.core.diagnostics.AivoSelfHealingEngine

class AivoApplication : Application() {
    override fun onCreate() {
        val bootStart = System.nanoTime()
        super.onCreate()
        AivoSelfHealingEngine.installGlobalCrashGuard(this)
        AivoServiceLocator.initialize(this)
        val bootMs = (System.nanoTime() - bootStart) / 1_000_000L
        AivoServiceLocator.diagnostics.recordMetric("startup_ms", bootMs.toString())
    }
}
