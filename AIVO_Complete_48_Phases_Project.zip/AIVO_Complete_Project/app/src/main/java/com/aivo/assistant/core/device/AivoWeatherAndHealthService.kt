package com.aivo.assistant.core.device

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request

@Serializable
data class WeatherSnapshot(
    val locationLabel: String,
    val temperatureC: Double?,
    val windSpeedKmh: Double?,
    val conditionSummary: String,
    val isAvailable: Boolean
)

data class HealthWellnessSummary(
    val sdkStatus: String,
    val stepsToday: Int,
    val avgHeartRateBpm: Int,
    val sleepHours: Double,
    val disclaimer: String = "Informational wellness summary only. Not a medical diagnosis."
)

class AivoWeatherAndHealthService(private val context: Context) {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun fetchWeather(lat: Double = 32.1877, lon: Double = 74.1945, label: String = "Selected Location"): WeatherSnapshot =
        withContext(Dispatchers.IO) {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true"
            runCatching {
                client.newCall(Request.Builder().url(url).get().build()).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    val tempMatch = Regex("\"temperature\":([0-9.-]+)").find(body)?.groupValues?.get(1)?.toDoubleOrNull()
                    val windMatch = Regex("\"windspeed\":([0-9.-]+)").find(body)?.groupValues?.get(1)?.toDoubleOrNull()
                    if (resp.isSuccessful && tempMatch != null) {
                        WeatherSnapshot(label, tempMatch, windMatch, "Live Open-Meteo telemetry", true)
                    } else {
                        WeatherSnapshot(label, null, null, "Weather telemetry unavailable", false)
                    }
                }
            }.getOrElse {
                WeatherSnapshot(label, null, null, "Offline / Network unavailable", false)
            }
        }

    fun checkHealthConnectStatus(): HealthWellnessSummary {
        val status = runCatching { HealthConnectClient.getSdkStatus(context) }.getOrDefault(-1)
        val label = when (status) {
            HealthConnectClient.SDK_AVAILABLE -> "HEALTH_CONNECT_AVAILABLE (Permission Required)"
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> "PROVIDER_UPDATE_REQUIRED"
            else -> "HEALTH_CONNECT_UNAVAILABLE_ON_DEVICE"
        }
        return HealthWellnessSummary(
            sdkStatus = label,
            stepsToday = 0,
            avgHeartRateBpm = 0,
            sleepHours = 0.0
        )
    }
}
