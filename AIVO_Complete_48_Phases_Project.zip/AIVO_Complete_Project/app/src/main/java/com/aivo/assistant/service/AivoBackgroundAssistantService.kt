package com.aivo.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.aivo.assistant.MainActivity
import com.aivo.assistant.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AivoBackgroundAssistantService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> _serviceState.value = "PAUSED"
            ACTION_STOP -> {
                _serviceState.value = "STOPPED"
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                _serviceState.value = "RUNNING"
                startForeground(NOTIF_ID, buildNotification("AIVO Assistant active (User-controlled)"))
            }
        }
        return START_STICKY
    }

    private fun buildNotification(statusText: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "AIVO Background Assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AIVO Personal Assistant")
            .setContentText(statusText)
            .setSmallIcon(R.drawable.ic_aivo_robot_head)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "aivo_bg_assistant"
        const val NOTIF_ID = 4815
        const val ACTION_START = "com.aivo.assistant.ACTION_START"
        const val ACTION_PAUSE = "com.aivo.assistant.ACTION_PAUSE"
        const val ACTION_STOP = "com.aivo.assistant.ACTION_STOP"

        private val _serviceState = MutableStateFlow("STOPPED")
        val serviceState: StateFlow<String> = _serviceState.asStateFlow()
    }
}
