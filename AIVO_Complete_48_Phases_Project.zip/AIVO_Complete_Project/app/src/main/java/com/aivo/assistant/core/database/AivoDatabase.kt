package com.aivo.assistant.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatMessageEntity::class,
        ReminderEntity::class,
        NotificationLogEntity::class,
        AiMemoryEntity::class,
        KnowledgeNoteEntity::class,
        WorkflowEntity::class,
        PairedDeviceEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AivoDatabase : RoomDatabase() {
    abstract fun dao(): AivoDao

    companion object {
        @Volatile private var instance: AivoDatabase? = null

        fun getInstance(context: Context): AivoDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AivoDatabase::class.java,
                    "aivo_core.db"
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
    }
}
