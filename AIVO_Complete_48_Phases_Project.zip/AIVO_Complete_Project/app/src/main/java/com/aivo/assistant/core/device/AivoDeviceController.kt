package com.aivo.assistant.core.device

import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import java.io.File

data class DeviceTelemetry(
    val model: String,
    val androidVersion: String,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val wifiEnabled: Boolean,
    val bluetoothAvailable: Boolean,
    val freeStorageGb: Double,
    val totalStorageGb: Double
)

class AivoDeviceController(private val context: Context) {

    fun getTelemetry(): DeviceTelemetry {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 0

        val wifiMgr = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val btMgr = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager

        val stat = StatFs(Environment.getDataDirectory().path)
        val totalGb = (stat.blockCountLong * stat.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
        val freeGb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)

        return DeviceTelemetry(
            model = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            batteryPercent = pct,
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            wifiEnabled = wifiMgr?.isWifiEnabled ?: false,
            bluetoothAvailable = btMgr?.adapter != null,
            freeStorageGb = String.format("%.2f", freeGb).toDouble(),
            totalStorageGb = String.format("%.2f", totalGb).toDouble()
        )
    }

    // Android 10+ compliant settings panel / intent launchers (never bypasses OS restrictions)
    fun openWifiSettings() {
        val action = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
        launchSafeIntent(Intent(action))
    }

    fun openBluetoothSettings() = launchSafeIntent(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    fun openDisplaySettings() = launchSafeIntent(Intent(Settings.ACTION_DISPLAY_SETTINGS))

    fun launchInstalledApp(packageName: String): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchSafeIntent(launchIntent)
        return true
    }

    // Phase 6: Explicit user-confirmed WhatsApp share workflow
    fun prepareWhatsAppShareIntent(phoneOrEmpty: String, message: String): Intent {
        val encoded = Uri.encode(message)
        val uri = if (phoneOrEmpty.isNotBlank()) {
            Uri.parse("https://wa.me/${phoneOrEmpty.filter { it.isDigit() }}?text=$encoded")
        } else {
            Uri.parse("https://wa.me/?text=$encoded")
        }
        return Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    // Phase 33: Navigation intent
    fun openNavigation(destination: String) {
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(destination)}")
        launchSafeIntent(Intent(Intent.ACTION_VIEW, uri))
    }

    // Phase 14: Scoped app-cache & large file candidate scanner (never deletes silently)
    fun scanAppCacheCandidates(): List<File> {
        return context.cacheDir.walkTopDown()
            .filter { it.isFile }
            .sortedByDescending { it.length() }
            .take(20)
            .toList()
    }

    fun deleteApprovedCacheFiles(files: List<File>): Int {
        var deleted = 0
        files.forEach { file ->
            if (file.canonicalPath.startsWith(context.cacheDir.canonicalPath) && file.delete()) {
                deleted++
            }
        }
        return deleted
    }

    private fun launchSafeIntent(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }
}
