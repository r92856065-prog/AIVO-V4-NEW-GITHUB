package com.aivo.assistant.core.updates

import android.app.Activity
import android.content.Context
import com.aivo.assistant.BuildConfig
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability

data class ReleaseInfo(
    val versionName: String,
    val versionCode: Int,
    val updateStatus: String,
    val releaseNotes: String
)

class AivoUpdateManager(private val context: Context) {
    private val appUpdateManager = AppUpdateManagerFactory.create(context)

    fun getCurrentVersionInfo(): ReleaseInfo = ReleaseInfo(
        versionName = BuildConfig.VERSION_NAME,
        versionCode = BuildConfig.VERSION_CODE,
        updateStatus = "INSTALLED_VERIFIED",
        releaseNotes = "AIVO v${BuildConfig.VERSION_NAME}: Complete 48-Phase Core, Multilingual Voice, 3D Avatar, Phone-to-PC Bridge & Play Update Support."
    )

    fun checkForPlayStoreUpdate(activity: Activity, immediate: Boolean = false, onStatus: (String) -> Unit) {
        val updateType = if (immediate) AppUpdateType.IMMEDIATE else AppUpdateType.FLEXIBLE
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                info.isUpdateTypeAllowed(updateType)
            ) {
                onStatus("Update available (Code ${info.availableVersionCode()}). Launching Play Store flow...")
                appUpdateManager.startUpdateFlowForResult(
                    info,
                    activity,
                    AppUpdateOptions.newBuilder(updateType).build(),
                    4801
                )
            } else {
                onStatus("No Play Store update pending (Installed: v${BuildConfig.VERSION_NAME}).")
            }
        }.addOnFailureListener {
            onStatus("Play Store In-App Update check unavailable in sideloaded/debug environment: ${it.message}")
        }
    }
}
