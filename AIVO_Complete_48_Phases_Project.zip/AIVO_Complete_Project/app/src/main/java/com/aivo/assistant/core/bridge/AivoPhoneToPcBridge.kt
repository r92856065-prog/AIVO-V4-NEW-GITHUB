package com.aivo.assistant.core.bridge

import com.aivo.assistant.core.database.PairedDeviceEntity
import com.aivo.assistant.core.security.AivoSecurityVault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.util.Base64

@Serializable
data class RemoteCommandPayload(
    val commandType: String, // LAUNCH_APP, SYSTEM_INFO, CLIPBOARD_SYNC
    val argument: String,
    val timestamp: Long = System.currentTimeMillis()
)

class AivoPhoneToPcBridge(private val vault: AivoSecurityVault) {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    fun parseQrPairingUri(qrPayload: String): PairedDeviceEntity? {
        // Expected format: aivo-pair://deviceId|deviceName|https://192.168.1.50:9443|pairingToken
        if (!qrPayload.startsWith("aivo-pair://")) return null
        val parts = qrPayload.removePrefix("aivo-pair://").split("|")
        if (parts.size < 4) return null
        val (deviceId, deviceName, endpoint, token) = parts
        vault.storeSecret("pc_token_$deviceId", token)
        val tokenHash = Base64.getEncoder().encodeToString(
            MessageDigest.getInstance("SHA-256").digest(token.toByteArray())
        )
        return PairedDeviceEntity(
            deviceId = deviceId,
            deviceName = deviceName,
            platform = "WINDOWS_DESKTOP",
            endpointUrl = endpoint,
            sharedTokenHash = tokenHash,
            connected = true
        )
    }

    suspend fun sendEncryptedCommand(device: PairedDeviceEntity, command: RemoteCommandPayload): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val token = vault.readSecret("pc_token_${device.deviceId}")
                    ?: error("Pairing token missing or revoked for ${device.deviceName}")
                val rawJson = json.encodeToString(command)
                val encrypted = vault.encryptPayload(rawJson, token.padEnd(32, '0').toByteArray())
                val req = Request.Builder()
                    .url(device.endpointUrl.trimEnd('/') + "/api/v1/remote-command")
                    .addHeader("X-AIVO-Device-Id", device.deviceId)
                    .post(encrypted.toRequestBody("text/plain".toMediaType()))
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) error("PC endpoint returned HTTP ${resp.code}")
                    resp.body?.string() ?: "Command queued on Windows (awaiting desktop confirmation)"
                }
            }
        }
}
