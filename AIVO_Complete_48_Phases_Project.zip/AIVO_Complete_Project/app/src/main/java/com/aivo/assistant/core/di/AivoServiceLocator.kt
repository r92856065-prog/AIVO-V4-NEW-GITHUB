package com.aivo.assistant.core.di

import android.content.Context
import com.aivo.assistant.core.ai.AivoAiGateway
import com.aivo.assistant.core.ai.AivoTaskAgentEngine
import com.aivo.assistant.core.bridge.AivoPhoneToPcBridge
import com.aivo.assistant.core.database.AivoBackupManager
import com.aivo.assistant.core.database.AivoDatabase
import com.aivo.assistant.core.device.AivoDeviceController
import com.aivo.assistant.core.device.AivoWeatherAndHealthService
import com.aivo.assistant.core.diagnostics.AivoSelfHealingEngine
import com.aivo.assistant.core.plugins.AivoPluginRegistry
import com.aivo.assistant.core.security.AivoSecurityVault
import com.aivo.assistant.core.updates.AivoUpdateManager
import com.aivo.assistant.core.voice.AivoVoiceEngine

object AivoServiceLocator {
    private var initialized = false
    lateinit var vault: AivoSecurityVault
    lateinit var database: AivoDatabase
    lateinit var backupManager: AivoBackupManager
    lateinit var diagnostics: AivoSelfHealingEngine
    lateinit var aiGateway: AivoAiGateway
    lateinit var taskAgent: AivoTaskAgentEngine
    lateinit var pluginRegistry: AivoPluginRegistry
    lateinit var voiceEngine: AivoVoiceEngine
    lateinit var deviceController: AivoDeviceController
    lateinit var weatherHealth: AivoWeatherAndHealthService
    lateinit var pcBridge: AivoPhoneToPcBridge
    lateinit var updateManager: AivoUpdateManager

    fun isInitialized(): Boolean = initialized

    fun initialize(context: Context) {
        if (initialized) return
        val appCtx = context.applicationContext
        vault = AivoSecurityVault(appCtx)
        database = AivoDatabase.getInstance(appCtx)
        backupManager = AivoBackupManager(database.dao(), vault)
        diagnostics = AivoSelfHealingEngine(appCtx)
        aiGateway = AivoAiGateway(vault)
        taskAgent = AivoTaskAgentEngine()
        pluginRegistry = AivoPluginRegistry()
        voiceEngine = AivoVoiceEngine(appCtx)
        deviceController = AivoDeviceController(appCtx)
        weatherHealth = AivoWeatherAndHealthService(appCtx)
        pcBridge = AivoPhoneToPcBridge(vault)
        updateManager = AivoUpdateManager(appCtx)
        initialized = true
    }
}
