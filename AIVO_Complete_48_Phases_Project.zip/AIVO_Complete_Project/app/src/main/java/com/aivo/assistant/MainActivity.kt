package com.aivo.assistant

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aivo.assistant.core.di.AivoServiceLocator
import com.aivo.assistant.service.AivoBackgroundAssistantService
import com.aivo.assistant.ui.AivoMainViewModel
import com.aivo.assistant.ui.components.AivoRobotAvatar
import com.aivo.assistant.ui.theme.AivoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AivoMainViewModel = viewModel()
            val dark by vm.darkTheme.collectAsState()
            val scale by vm.fontScale.collectAsState()
            AivoTheme(darkTheme = dark, fontScaleMultiplier = scale) {
                AivoRootScreen(activity = this, vm = vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AivoRootScreen(activity: ComponentActivity, vm: AivoMainViewModel) {
    val onboarded by vm.onboardingComplete.collectAsState()
    if (!onboarded) {
        OnboardingScreen(onComplete = { vm.completeOnboarding(it) })
        return
    }

    var tabIndex by remember { mutableIntStateOf(0) }
    val avatarState by AivoServiceLocator.voiceEngine.avatarState.collectAsState()
    val banner by vm.statusBanner.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AIVO — ONE AI. EVERY TASK.", style = MaterialTheme.typography.titleMedium)
                        Text(banner, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val perms = buildList {
                            add(Manifest.permission.RECORD_AUDIO)
                            add(Manifest.permission.CAMERA)
                            add(Manifest.permission.ACCESS_COARSE_LOCATION)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }.toTypedArray()
                        permissionLauncher.launch(perms)
                    }) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Request Permissions")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tabIndex == 0, onClick = { tabIndex = 0 }, icon = { Icon(Icons.Default.Chat, "Chat") }, label = { Text("Chat & Voice") })
                NavigationBarItem(selected = tabIndex == 1, onClick = { tabIndex = 1 }, icon = { Icon(Icons.Default.Build, "Studios") }, label = { Text("Studios") })
                NavigationBarItem(selected = tabIndex == 2, onClick = { tabIndex = 2 }, icon = { Icon(Icons.Default.Devices, "Control") }, label = { Text("Device & PC") })
                NavigationBarItem(selected = tabIndex == 3, onClick = { tabIndex = 3 }, icon = { Icon(Icons.Default.Settings, "Settings") }, label = { Text("Settings") })
            }
        }
    ) { inner ->
        when (tabIndex) {
            0 -> ChatAndVoiceTab(inner, vm, avatarState)
            1 -> StudiosAndProductivityTab(inner, vm)
            2 -> DeviceHealthAndPcTab(inner, vm)
            3 -> SettingsSecurityAndUpdatesTab(inner, activity, vm)
        }
    }
}

@Composable
private fun OnboardingScreen(onComplete: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AivoRobotAvatar(state = com.aivo.assistant.core.voice.AvatarState.SPEAKING)
        Spacer(Modifier.height(16.dp))
        Text("AIVO", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        Text("ONE AI. EVERY TASK.", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        Text("Privacy-first personal intelligence across Android & Windows. Voice, automation, memory, and device control under your explicit permission.")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Your Name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onComplete(name) }, modifier = Modifier.fillMaxWidth()) {
            Text("Initialize AIVO")
        }
    }
}

@Composable
private fun ChatAndVoiceTab(padding: PaddingValues, vm: AivoMainViewModel, avatarState: com.aivo.assistant.core.voice.AvatarState) {
    val messages by vm.messages.collectAsState()
    val loading by vm.isLoadingAi.collectAsState()
    val transcript by AivoServiceLocator.voiceEngine.transcript.collectAsState()
    var input by remember { mutableStateOf("") }
    var speakReplies by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            AivoRobotAvatar(state = avatarState, modifier = Modifier.padding(end = 12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Avatar State: ${avatarState.name}", style = MaterialTheme.typography.titleMedium)
                if (transcript.isNotBlank()) Text("Heard: $transcript", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        AivoServiceLocator.voiceEngine.startListening { heard ->
                            vm.sendChatPrompt(heard, speakReply = true)
                        }
                    }) {
                        Icon(Icons.Default.Mic, contentDescription = "Hey AIVO Voice Input")
                        Text("Hey AIVO")
                    }
                    OutlinedButton(onClick = { AivoServiceLocator.voiceEngine.stopSpeaking() }) { Text("Mute") }
                }
            }
        }
        if (loading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { msg ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${msg.sender} • ${msg.languageCode.uppercase()}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                        Text(msg.content, style = MaterialTheme.typography.bodyLarge)
                        if (msg.sourcesJson.isNotBlank()) {
                            Text("Sources: ${msg.sourcesJson}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Ask AIVO or /search topic...") },
                modifier = Modifier.weight(1f).semantics { contentDescription = "AI Chat Input" }
            )
            Button(onClick = {
                vm.sendChatPrompt(input, speakReply = speakReplies)
                input = ""
            }) { Text("Send") }
        }
    }
}

@Composable
private fun StudiosAndProductivityTab(padding: PaddingValues, vm: AivoMainViewModel) {
    val reminders by vm.reminders.collectAsState()
    val memories by vm.memories.collectAsState()
    val workflows by vm.workflows.collectAsState()
    var reminderTitle by remember { mutableStateOf("") }
    var memoryInput by remember { mutableStateOf("") }
    var agentGoal by remember { mutableStateOf("") }
    val agentSteps by AivoServiceLocator.taskAgent.steps.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phase 8: Reminders & Daily Tasks", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = reminderTitle, onValueChange = { reminderTitle = it }, label = { Text("Task") }, modifier = Modifier.weight(1f))
                        Button(onClick = { if (reminderTitle.isNotBlank()) { vm.addReminder(reminderTitle, 30); reminderTitle = "" } }) { Text("Add") }
                    }
                    reminders.forEach { item ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = item.completed, onCheckedChange = { vm.toggleReminder(item) })
                            Text(item.title, modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phase 35: AI Task Execution & Agent Workspace", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = agentGoal, onValueChange = { agentGoal = it }, label = { Text("Multi-step goal") }, modifier = Modifier.weight(1f))
                        Button(onClick = { if (agentGoal.isNotBlank()) AivoServiceLocator.taskAgent.planGoal(agentGoal) }) { Text("Plan") }
                    }
                    agentSteps.forEach { step ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("${step.stepNumber}. ${step.description} [${step.status}]", modifier = Modifier.weight(1f))
                            if (step.status == "AWAITING_APPROVAL") {
                                Button(onClick = { AivoServiceLocator.taskAgent.approveStep(step.stepNumber) }) { Text("Approve") }
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phase 43: Long-Term AI Memory (${memories.size})", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = memoryInput, onValueChange = { memoryInput = it }, label = { Text("Save approved preference") }, modifier = Modifier.weight(1f))
                        Button(onClick = { if (memoryInput.isNotBlank()) { vm.addMemory(memoryInput); memoryInput = "" } }) { Text("Save") }
                    }
                    memories.forEach { m ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("• ${m.content}", modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { vm.deleteMemory(m.id) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Phase 11, 12, 31: Dev Studio, Video Studio & Automation (${workflows.size})", style = MaterialTheme.typography.titleMedium)
                    Text("Dev Studio: Kotlin/Python/JSON syntax & safe sandbox validator active.")
                    Text("Video Studio: Scoped MediaStore picker & FFmpeg/Cloud provider hook ready.")
                    Button(onClick = { vm.addWorkflow("Morning Briefing", "MORNING_BRIEFING", "BRIEFING") }) { Text("Add Morning Briefing Workflow") }
                }
            }
        }
    }
}

@Composable
private fun DeviceHealthAndPcTab(padding: PaddingValues, vm: AivoMainViewModel) {
    val context = LocalContext.current
    val telemetry = remember { AivoServiceLocator.deviceController.getTelemetry() }
    val health = remember { AivoServiceLocator.weatherHealth.checkHealthConnectStatus() }
    val weather by vm.weather.collectAsState()
    val pairedDevices by vm.pairedDevices.collectAsState()
    val bgState by AivoBackgroundAssistantService.serviceState.collectAsState()
    var qrUri by remember { mutableStateOf("aivo-pair://win-01|Workstation-PC|https://192.168.1.100:9443|demo-token-2026") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Phase 5 & 9: Device Telemetry & Weather", style = MaterialTheme.typography.titleMedium)
                    Text("Device: ${telemetry.model} • ${telemetry.androidVersion}")
                    Text("Battery: ${telemetry.batteryPercent}% (${if (telemetry.isCharging) "Charging" else "Discharging"}) • Free Storage: ${telemetry.freeStorageGb} / ${telemetry.totalStorageGb} GB")
                    Text("Weather (${weather.locationLabel}): ${weather.temperatureC ?: "N/A"}°C — ${weather.conditionSummary}")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { AivoServiceLocator.deviceController.openWifiSettings() }) { Text("Wi-Fi") }
                        OutlinedButton(onClick = { AivoServiceLocator.deviceController.openBluetoothSettings() }) { Text("Bluetooth") }
                        OutlinedButton(onClick = { AivoServiceLocator.deviceController.openDisplaySettings() }) { Text("Brightness") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Phase 13 & 15: Health Wellness & Background Assistant", style = MaterialTheme.typography.titleMedium)
                    Text("Health Connect: ${health.sdkStatus}")
                    Text(health.disclaimer, style = MaterialTheme.typography.bodyMedium)
                    Text("Background Service State: $bgState")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            context.startForegroundService(Intent(context, AivoBackgroundAssistantService::class.java).setAction(AivoBackgroundAssistantService.ACTION_START))
                        }) { Text("Start Assistant") }
                        OutlinedButton(onClick = {
                            context.startService(Intent(context, AivoBackgroundAssistantService::class.java).setAction(AivoBackgroundAssistantService.ACTION_STOP))
                        }) { Text("Stop") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phase 45: Phone-to-PC Remote AIVO Bridge", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = qrUri, onValueChange = { qrUri = it }, label = { Text("Pairing URI / QR Payload") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { vm.pairPcFromQr(qrUri) }) { Text("Pair Windows PC") }
                    pairedDevices.forEach { dev ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("${dev.deviceName} (${dev.platform})", modifier = Modifier.weight(1f))
                            Button(onClick = { vm.sendRemotePcCommand(dev, "SYSTEM_INFO", "STATUS") }) { Text("Ping PC") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSecurityAndUpdatesTab(padding: PaddingValues, activity: ComponentActivity, vm: AivoMainViewModel) {
    val dark by vm.darkTheme.collectAsState()
    val scale by vm.fontScale.collectAsState()
    var endpoint by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var searchKey by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf(1.0f) }
    var pitch by remember { mutableStateOf(1.0f) }
    val release = remember { AivoServiceLocator.updateManager.getCurrentVersionInfo() }
    var updateMsg by remember { mutableStateOf(release.releaseNotes) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phase 17, 29, 38, 47: Appearance, Multilingual & Voice Customization", style = MaterialTheme.typography.titleMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Dark Theme", modifier = Modifier.weight(1f))
                        Switch(checked = dark, onCheckedChange = { vm.setDarkTheme(it) })
                    }
                    Text("Accessibility Text Scale: ${String.format("%.2f", scale)}x")
                    Slider(value = scale, onValueChange = { vm.setFontScale(it) }, valueRange = 0.85f..1.4f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { vm.setLanguage("en") }) { Text("English") }
                        OutlinedButton(onClick = { vm.setLanguage("ur") }) { Text("اردو (Urdu)") }
                        OutlinedButton(onClick = { vm.setLanguage("hi") }) { Text("हिन्दी (Hindi)") }
                    }
                    Text("Voice Rate: ${String.format("%.2f", rate)} • Pitch: ${String.format("%.2f", pitch)}")
                    Slider(value = rate, onValueChange = { rate = it; AivoServiceLocator.voiceEngine.configureVoice("en", rate, pitch) }, valueRange = 0.6f..1.6f)
                    Button(onClick = { AivoServiceLocator.voiceEngine.speak("AIVO voice calibration active. One AI, every task.") }) { Text("Preview Selected Voice") }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phase 10 & 18: Encrypted API Vault (Zero Hardcoded Secrets)", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = endpoint, onValueChange = { endpoint = it }, label = { Text("HTTPS AI Endpoint") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Cloud AI API Key") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = searchKey, onValueChange = { searchKey = it }, label = { Text("Web Search Key") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { vm.saveCloudCredentials(endpoint, apiKey, searchKey); apiKey = ""; searchKey = "" }) {
                        Text("Save to Encrypted Keystore")
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phase 21 & 48: Diagnostics & Google Play In-App Updates", style = MaterialTheme.typography.titleMedium)
                    Text("Installed: v${release.versionName} (Code ${release.versionCode})")
                    Text(updateMsg, style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = {
                        AivoServiceLocator.updateManager.checkForPlayStoreUpdate(activity, immediate = false) { updateMsg = it }
                    }) { Text("Check Play Store Updates") }
                }
            }
        }
    }
}
