package com.aivo.assistant.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.aivo.assistant.core.database.NotificationLogEntity
import com.aivo.assistant.core.di.AivoServiceLocator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AivoNotificationBridgeService : NotificationListenerService() {
    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val pkg = sbn?.packageName ?: return
        if (pkg == packageName) return
        val extras = sbn.notification?.extras ?: return
        val title = extras.getString("android.title") ?: return
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        val category = if (pkg.contains("whatsapp")) "WHATSAPP" else "SYSTEM"

        scope.launch {
            if (AivoServiceLocator.isInitialized()) {
                AivoServiceLocator.database.dao().insertNotification(
                    NotificationLogEntity(
                        category = category,
                        priority = "NORMAL",
                        title = "[$pkg] $title",
                        body = text
                    )
                )
            }
        }
    }
}
