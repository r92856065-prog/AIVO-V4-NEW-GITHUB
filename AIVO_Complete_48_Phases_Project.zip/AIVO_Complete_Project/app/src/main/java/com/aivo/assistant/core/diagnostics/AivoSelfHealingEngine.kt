package com.aivo.assistant.core.diagnostics

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class AivoSelfHealingEngine(private val context: Context) {
    private val logs = CopyOnWriteArrayList<String>()
    private val metrics = ConcurrentHashMap<String, String>()
    private val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun logEvent(level: String, module: String, message: String) {
        val entry = "[${formatter.format(Date())}] [$level] [$module] $message"
        logs.add(entry)
        if (logs.size > 500) logs.removeAt(0)
        runCatching {
            File(context.filesDir, "aivo_diagnostics.log").appendText(entry + "\n")
        }
    }

    fun recordMetric(key: String, value: String) {
        metrics[key] = value
    }

    fun getDiagnosticReport(): String = buildString {
        appendLine("=== AIVO DIAGNOSTICS & SELF-HEALING REPORT ===")
        metrics.forEach { (k, v) -> appendLine("Metric[$k] = $v") }
        appendLine("Crash Loop Guard: ACTIVE (Safe Mode Threshold = 3 crashes / 60s)")
        appendLine("Recent Events (${logs.size}):")
        logs.takeLast(25).forEach { appendLine(it) }
    }

    companion object {
        fun installGlobalCrashGuard(context: Context) {
            val prefs = context.getSharedPreferences("aivo_crash_guard", Context.MODE_PRIVATE)
            val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                val now = System.currentTimeMillis()
                val lastCrash = prefs.getLong("last_crash_ts", 0L)
                val count = if (now - lastCrash < 60_000L) prefs.getInt("crash_count", 0) + 1 else 1
                prefs.edit()
                    .putLong("last_crash_ts", now)
                    .putInt("crash_count", count)
                    .putBoolean("safe_mode_active", count >= 3)
                    .putString("last_error", throwable.message ?: throwable.javaClass.simpleName)
                    .apply()
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }
}
