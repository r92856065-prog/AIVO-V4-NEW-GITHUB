package com.aivo.assistant.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: String,
    val sender: String, // USER, AIVO, SYSTEM
    val content: String,
    val languageCode: String = "en",
    val timestamp: Long = System.currentTimeMillis(),
    val sourcesJson: String = "[]"
)

@Serializable
@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val dueAtMillis: Long,
    val repeatRule: String = "NONE", // NONE, DAILY, WEEKLY
    val completed: Boolean = false
)

@Serializable
@Entity(tableName = "notifications_log")
data class NotificationLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // SYSTEM, WHATSAPP, REMINDER, UPDATE, PROACTIVE
    val priority: String, // HIGH, NORMAL, LOW
    val title: String,
    val body: String,
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "ai_memories")
data class AiMemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // PREFERENCE, INSTRUCTION, FACT
    val content: String,
    val userApproved: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "knowledge_notes")
data class KnowledgeNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val tags: String,
    val body: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "automation_workflows")
data class WorkflowEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val triggerType: String, // SCHEDULE, BATTERY_LOW, MORNING_BRIEFING, MANUAL
    val actionType: String,  // BRIEFING, REMINDER, PC_COMMAND, STORAGE_SCAN
    val requiresConfirmation: Boolean = true,
    val enabled: Boolean = true,
    val lastRunLog: String = "Never executed"
)

@Serializable
@Entity(tableName = "paired_devices")
data class PairedDeviceEntity(
    @PrimaryKey val deviceId: String,
    val deviceName: String,
    val platform: String, // WINDOWS_DESKTOP
    val endpointUrl: String,
    val sharedTokenHash: String,
    val connected: Boolean = false,
    val pairedAt: Long = System.currentTimeMillis()
)
