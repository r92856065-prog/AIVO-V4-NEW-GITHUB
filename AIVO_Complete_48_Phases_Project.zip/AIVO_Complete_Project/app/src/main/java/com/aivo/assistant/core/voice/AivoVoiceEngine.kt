package com.aivo.assistant.core.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class AvatarState { IDLE, LISTENING, THINKING, SPEAKING }

data class VoiceOption(
    val id: String,
    val displayName: String,
    val languageTag: String,
    val genderLabel: String,
    val available: Boolean
)

class AivoVoiceEngine(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var speechRecognizer: SpeechRecognizer? = null

    private val _avatarState = MutableStateFlow(AvatarState.IDLE)
    val avatarState: StateFlow<AvatarState> = _avatarState.asStateFlow()

    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript.asStateFlow()

    private val _voiceError = MutableStateFlow<String?>(null)
    val voiceError: StateFlow<String?> = _voiceError.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<VoiceOption>> = _availableVoices.asStateFlow()

    private var speechRate = 1.0f
    private var speechPitch = 1.0f
    private var selectedLanguage = "en"

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { _avatarState.value = AvatarState.SPEAKING }
                override fun onDone(utteranceId: String?) { _avatarState.value = AvatarState.IDLE }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { _avatarState.value = AvatarState.IDLE }
            })
            refreshVoices()
        } else {
            _voiceError.value = "TTS engine initialization unavailable on this device."
        }
    }

    fun refreshVoices() {
        val engineVoices: Set<Voice> = runCatching { tts?.voices.orEmpty() }.getOrDefault(emptySet())
        val supportedLocales = listOf(
            Triple("en-US", "English (US) Neural", "Female/Neutral"),
            Triple("en-GB", "English (UK) Studio", "Male"),
            Triple("ur-PK", "Urdu (Pakistan)", "Female"),
            Triple("hi-IN", "Hindi (India)", "Male")
        )
        _availableVoices.value = supportedLocales.map { (tag, label, gender) ->
            val locale = Locale.forLanguageTag(tag)
            val match = engineVoices.firstOrNull { it.locale.language == locale.language }
            VoiceOption(
                id = match?.name ?: "fallback_$tag",
                displayName = label,
                languageTag = tag,
                genderLabel = gender,
                available = match != null || tag.startsWith("en")
            )
        }
    }

    fun configureVoice(languageCode: String, rate: Float, pitch: Float, voiceId: String? = null) {
        selectedLanguage = languageCode
        speechRate = rate.coerceIn(0.5f, 2.0f)
        speechPitch = pitch.coerceIn(0.5f, 2.0f)
        tts?.language = Locale.forLanguageTag(
            when (languageCode) {
                "ur" -> "ur-PK"
                "hi" -> "hi-IN"
                else -> "en-US"
            }
        )
        tts?.setSpeechRate(speechRate)
        tts?.setPitch(speechPitch)
        if (!voiceId.isNullOrBlank()) {
            tts?.voices?.firstOrNull { it.name == voiceId }?.let { tts?.voice = it }
        }
    }

    fun speak(text: String) {
        stopSpeaking()
        _avatarState.value = AvatarState.SPEAKING
        val params = Bundle()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "aivo_utt_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        tts?.stop()
        if (_avatarState.value == AvatarState.SPEAKING) {
            _avatarState.value = AvatarState.IDLE
        }
    }

    fun startListening(languageCode: String = selectedLanguage, onFinalResult: (String) -> Unit) {
        _voiceError.value = null
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceError.value = "Speech recognition service is not installed on this device."
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { _avatarState.value = AvatarState.LISTENING }
                override fun onBeginningOfSpeech() { _avatarState.value = AvatarState.LISTENING }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { _avatarState.value = AvatarState.THINKING }
                override fun onError(error: Int) {
                    _avatarState.value = AvatarState.IDLE
                    _voiceError.value = "Speech recognition error code: $error"
                }
                override fun onResults(results: Bundle?) {
                    _avatarState.value = AvatarState.IDLE
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    val cleaned = heard.replace(Regex("^hey aivo[,\\s]*", RegexOption.IGNORE_CASE), "").trim()
                    _transcript.value = cleaned
                    if (cleaned.isNotBlank()) onFinalResult(cleaned)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) _transcript.value = partial
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE,
                when (languageCode) {
                    "ur" -> "ur-PK"
                    "hi" -> "hi-IN"
                    else -> "en-US"
                }
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    fun setThinking() { _avatarState.value = AvatarState.THINKING }
    fun setIdle() { _avatarState.value = AvatarState.IDLE }

    fun shutdown() {
        speechRecognizer?.destroy()
        tts?.shutdown()
    }
}
