package com.aivo.assistant.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.aivo.assistant.R

class AivoReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("reminder_title") ?: "AIVO Scheduled Reminder"
        val mgr = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mgr.createNotificationChannel(
                NotificationChannel("aivo_reminders", "AIVO Reminders", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(context, "aivo_reminders")
            .setSmallIcon(R.drawable.ic_aivo_robot_head)
            .setContentTitle("AIVO Task Reminder")
            .setContentText(title)
            .setAutoCancel(true)
            .build()
        mgr.notify(System.currentTimeMillis().toInt(), notification)
    }
}
