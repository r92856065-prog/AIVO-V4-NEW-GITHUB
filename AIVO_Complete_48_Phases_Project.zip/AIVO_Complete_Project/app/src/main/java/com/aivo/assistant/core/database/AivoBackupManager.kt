package com.aivo.assistant.core.database

import com.aivo.assistant.core.security.AivoSecurityVault
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class AivoBackupBundle(
    val schemaVersion: Int = 1,
    val exportedAt: Long,
    val messages: List<ChatMessageEntity>,
    val memories: List<AiMemoryEntity>
)

class AivoBackupManager(
    private val dao: AivoDao,
    private val vault: AivoSecurityVault
) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    suspend fun exportEncryptedBackup(passphrase: String): String {
        val bundle = AivoBackupBundle(
            exportedAt = System.currentTimeMillis(),
            messages = dao.getAllMessages(),
            memories = dao.getApprovedMemories()
        )
        val rawJson = json.encodeToString(bundle)
        val keyBytes = passphrase.padEnd(32, '0').toByteArray(Charsets.UTF_8)
        return vault.encryptPayload(rawJson, keyBytes)
    }

    suspend fun restoreEncryptedBackup(cipherText: String, passphrase: String): Result<Int> = runCatching {
        val keyBytes = passphrase.padEnd(32, '0').toByteArray(Charsets.UTF_8)
        val rawJson = vault.decryptPayload(cipherText, keyBytes)
        val bundle = json.decodeFromString<AivoBackupBundle>(rawJson)
        var restored = 0
        bundle.memories.forEach {
            dao.insertMemory(it.copy(id = 0))
            restored++
        }
        bundle.messages.forEach {
            dao.insertMessage(it.copy(id = 0))
            restored++
        }
        restored
    }
}
