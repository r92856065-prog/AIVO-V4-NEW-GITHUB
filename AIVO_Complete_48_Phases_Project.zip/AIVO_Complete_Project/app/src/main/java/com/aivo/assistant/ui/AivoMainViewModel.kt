package com.aivo.assistant.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aivo.assistant.core.bridge.RemoteCommandPayload
import com.aivo.assistant.core.database.AiMemoryEntity
import com.aivo.assistant.core.database.ChatMessageEntity
import com.aivo.assistant.core.database.KnowledgeNoteEntity
import com.aivo.assistant.core.database.NotificationLogEntity
import com.aivo.assistant.core.database.PairedDeviceEntity
import com.aivo.assistant.core.database.ReminderEntity
import com.aivo.assistant.core.database.WorkflowEntity
import com.aivo.assistant.core.device.WeatherSnapshot
import com.aivo.assistant.core.di.AivoServiceLocator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AivoMainViewModel : ViewModel() {
    private val dao = AivoServiceLocator.database.dao()

    private val _onboardingComplete = MutableStateFlow(
        AivoServiceLocator.vault.readSecret("onboarding_done") == "true"
    )
    val onboardingComplete: StateFlow<Boolean> = _onboardingComplete.asStateFlow()

    private val _currentSessionId = MutableStateFlow("default_session")
    val currentSessionId: StateFlow<String> = _currentSessionId.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("en")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _darkTheme = MutableStateFlow(true)
    val darkTheme: StateFlow<Boolean> = _darkTheme.asStateFlow()

    private val _fontScale = MutableStateFlow(1.0f)
    val fontScale: StateFlow<Float> = _fontScale.asStateFlow()

    private val _isLoadingAi = MutableStateFlow(false)
    val isLoadingAi: StateFlow<Boolean> = _isLoadingAi.asStateFlow()

    private val _weather = MutableStateFlow(WeatherSnapshot("Loading...", null, null, "Initializing", false))
    val weather: StateFlow<WeatherSnapshot> = _weather.asStateFlow()

    private val _statusBanner = MutableStateFlow("AIVO All 48 Phases Ready")
    val statusBanner: StateFlow<String> = _statusBanner.asStateFlow()

    val messages = dao.observeMessages("default_session")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders = dao.observeReminders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications = dao.observeNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories = dao.observeMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workflows = dao.observeWorkflows()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pairedDevices = dao.observePairedDevices()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        refreshWeather()
        viewModelScope.launch {
            if (dao.getApprovedMemories().isEmpty()) {
                dao.insertMemory(AiMemoryEntity(category = "INSTRUCTION", content = "Always confirm before sending external messages or PC commands."))
            }
        }
    }

    fun completeOnboarding(userName: String) {
        AivoServiceLocator.vault.storeSecret("user_display_name", userName.ifBlank { "Commander" })
        AivoServiceLocator.vault.storeSecret("onboarding_done", "true")
        _onboardingComplete.value = true
    }

    fun setLanguage(lang: String) {
        _selectedLanguage.value = lang
        AivoServiceLocator.voiceEngine.configureVoice(lang, 1.0f, 1.0f)
    }

    fun setDarkTheme(dark: Boolean) { _darkTheme.value = dark }
    fun setFontScale(scale: Float) { _fontScale.value = scale.coerceIn(0.85f, 1.4f) }

    fun sendChatPrompt(prompt: String, speakReply: Boolean = false) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            dao.insertMessage(ChatMessageEntity(sessionId = _currentSessionId.value, sender = "USER", content = prompt, languageCode = _selectedLanguage.value))
            _isLoadingAi.value = true
            AivoServiceLocator.voiceEngine.setThinking()
            val memoryList = dao.getApprovedMemories().map { it.content }
            val result = if (prompt.startsWith("/search ", ignoreCase = true)) {
                AivoServiceLocator.aiGateway.searchWebWithCitations(prompt.removePrefix("/search ").trim())
            } else {
                AivoServiceLocator.aiGateway.generateResponse(prompt, _selectedLanguage.value, memoryList)
            }
            dao.insertMessage(
                ChatMessageEntity(
                    sessionId = _currentSessionId.value,
                    sender = "AIVO",
                    content = result.text,
                    languageCode = _selectedLanguage.value,
                    sourcesJson = result.sources.joinToString()
                )
            )
            _isLoadingAi.value = false
            AivoServiceLocator.voiceEngine.setIdle()
            if (speakReply) {
                AivoServiceLocator.voiceEngine.speak(result.text)
            }
        }
    }

    fun addReminder(title: String, delayMinutes: Int) {
        viewModelScope.launch {
            dao.insertReminder(ReminderEntity(title = title, dueAtMillis = System.currentTimeMillis() + delayMinutes * 60_000L))
            dao.insertNotification(NotificationLogEntity(category = "REMINDER", priority = "NORMAL", title = "Reminder Scheduled", body = title))
        }
    }

    fun toggleReminder(item: ReminderEntity) {
        viewModelScope.launch { dao.updateReminder(item.copy(completed = !item.completed)) }
    }

    fun addMemory(content: String) {
        viewModelScope.launch { dao.insertMemory(AiMemoryEntity(category = "PREFERENCE", content = content)) }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { dao.deleteMemory(id) }
    }

    fun saveKnowledgeNote(title: String, category: String, tags: String, body: String) {
        viewModelScope.launch { dao.insertNote(KnowledgeNoteEntity(title = title, category = category, tags = tags, body = body)) }
    }

    fun addWorkflow(name: String, trigger: String, action: String) {
        viewModelScope.launch { dao.insertWorkflow(WorkflowEntity(name = name, triggerType = trigger, actionType = action)) }
    }

    fun pairPcFromQr(qrPayload: String) {
        viewModelScope.launch {
            val device = AivoServiceLocator.pcBridge.parseQrPairingUri(qrPayload)
            if (device != null) {
                dao.upsertPairedDevice(device)
                _statusBanner.value = "Paired with ${device.deviceName}"
            } else {
                _statusBanner.value = "Invalid pairing QR URI"
            }
        }
    }

    fun sendRemotePcCommand(device: PairedDeviceEntity, commandType: String, argument: String) {
        viewModelScope.launch {
            val res = AivoServiceLocator.pcBridge.sendEncryptedCommand(device, RemoteCommandPayload(commandType, argument))
            _statusBanner.value = res.getOrElse { "PC Bridge: ${it.message}" }
        }
    }

    fun refreshWeather() {
        viewModelScope.launch {
            _weather.value = AivoServiceLocator.weatherHealth.fetchWeather()
        }
    }

    fun saveCloudCredentials(endpoint: String, apiKey: String, searchKey: String) {
        if (endpoint.isNotBlank()) AivoServiceLocator.vault.storeSecret("cloud_ai_endpoint", endpoint.trim())
        if (apiKey.isNotBlank()) AivoServiceLocator.vault.storeSecret("cloud_ai_api_key", apiKey.trim())
        if (searchKey.isNotBlank()) AivoServiceLocator.vault.storeSecret("web_search_api_key", searchKey.trim())
        _statusBanner.value = "Encrypted credentials updated in Android Keystore Vault"
    }
}
