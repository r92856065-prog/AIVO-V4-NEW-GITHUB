pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "AIVO"
include(":app")
include(":core:common")
include(":core:security")
include(":core:database")
include(":core:network")
include(":core:voice")
include(":core:ai")
include(":desktop")
