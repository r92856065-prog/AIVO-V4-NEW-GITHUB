# AIVO — ONE AI. EVERY TASK.
**Complete 48-Phase Cross-Platform Personal AI Assistant (Android + Windows Desktop)**

## Overview
AIVO is a brand-new, independent personal AI assistant engineered from scratch with Kotlin, Jetpack Compose, Room, Android Keystore AES-256-GCM encryption, and a JVM/Swing Windows Desktop companion.

## Architecture
- `app/`: Android Application (`com.aivo.assistant`, MinSDK 26, TargetSDK 35, Version 4.8.0 / Code 4800)
- `desktop/`: Windows Desktop Companion Application (`com.aivo.desktop`) with Phone-to-PC encrypted command listener
- `docs/`: GitHub Pages static web portal (`docs/index.html`)
- `.github/workflows/`: Automated CI build and test pipeline

## Build & Verification Instructions
1. Copy `local.properties.example` to `local.properties` and configure `sdk.dir`.
2. Build Android Debug APK & Run Unit Tests:
   ```bash
   gradle :app:testDebugUnitTest :app:assembleDebug
   ```
3. Build Release AAB (after setting signing credentials in `local.properties` or environment variables):
   ```bash
   gradle :app:bundleRelease
   ```
4. Run Windows Desktop Companion:
   ```bash
   gradle :desktop:run
   ```
